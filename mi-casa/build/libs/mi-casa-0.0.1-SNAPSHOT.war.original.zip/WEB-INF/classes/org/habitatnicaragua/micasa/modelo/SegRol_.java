package org.habitatnicaragua.micasa.modelo;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(SegRol.class)
public abstract class SegRol_ {

	public static volatile SingularAttribute<SegRol, Auditoria> auditoria;
	public static volatile SingularAttribute<SegRol, String> rol;

}

