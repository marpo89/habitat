package org.habitatnicaragua.micasa.modelo;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(PryProyectoTmp.class)
public abstract class PryProyectoTmp_ {

	public static volatile SingularAttribute<PryProyectoTmp, Long> idProyecto;
	public static volatile SingularAttribute<PryProyectoTmp, String> tecnico;

}

