package org.habitatnicaragua.micasa.modelo;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(CmsContenidoNivel2.class)
public abstract class CmsContenidoNivel2_ {

	public static volatile SingularAttribute<CmsContenidoNivel2, String> youtube;
	public static volatile SingularAttribute<CmsContenidoNivel2, String> contenido;
	public static volatile SingularAttribute<CmsContenidoNivel2, String> archivo;
	public static volatile SingularAttribute<CmsContenidoNivel2, PerUsuario> duenio;
	public static volatile SingularAttribute<CmsContenidoNivel2, Long> idContenido;
	public static volatile SingularAttribute<CmsContenidoNivel2, String> titulo;
	public static volatile SingularAttribute<CmsContenidoNivel2, Auditoria> auditoria;

}

