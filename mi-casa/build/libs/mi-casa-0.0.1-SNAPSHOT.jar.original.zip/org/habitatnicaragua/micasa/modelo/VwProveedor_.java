package org.habitatnicaragua.micasa.modelo;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(VwProveedor.class)
public abstract class VwProveedor_ {

	public static volatile SingularAttribute<VwProveedor, String> whatsapp;
	public static volatile SingularAttribute<VwProveedor, String> direccionFisica;
	public static volatile SingularAttribute<VwProveedor, String> contacto;
	public static volatile SingularAttribute<VwProveedor, String> codigoActivacion;
	public static volatile SingularAttribute<VwProveedor, String> idUsuario;
	public static volatile SingularAttribute<VwProveedor, String> facebook;
	public static volatile SingularAttribute<VwProveedor, Long> cantOfertas;
	public static volatile SingularAttribute<VwProveedor, String> avatar;
	public static volatile SingularAttribute<VwProveedor, String> rol;
	public static volatile SingularAttribute<VwProveedor, String> nombres;
	public static volatile SingularAttribute<VwProveedor, String> twitter;
	public static volatile SingularAttribute<VwProveedor, String> sitioWeb;
	public static volatile SingularAttribute<VwProveedor, String> puntaje;
	public static volatile SingularAttribute<VwProveedor, String> correo;
	public static volatile SingularAttribute<VwProveedor, String> id;
	public static volatile SingularAttribute<VwProveedor, String> telefonos;
	public static volatile SingularAttribute<VwProveedor, Auditoria> auditoria;
	public static volatile SingularAttribute<VwProveedor, Boolean> activo;

}

