package org.habitatnicaragua.micasa.modelo;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(VwActividadUsuarioNivel2.class)
public abstract class VwActividadUsuarioNivel2_ {

	public static volatile SingularAttribute<VwActividadUsuarioNivel2, Date> fechaLogin;
	public static volatile SingularAttribute<VwActividadUsuarioNivel2, Date> fechaMuro;
	public static volatile SingularAttribute<VwActividadUsuarioNivel2, String> idUsuario;
	public static volatile SingularAttribute<VwActividadUsuarioNivel2, String> correo;
	public static volatile SingularAttribute<VwActividadUsuarioNivel2, Date> fechaOferta;
	public static volatile SingularAttribute<VwActividadUsuarioNivel2, String> nombres;
	public static volatile SingularAttribute<VwActividadUsuarioNivel2, Boolean> activo;

}

